class Menu
  attr_accessor :name
  attr_accessor :price

  def get_total_price
    puts 'Mời bạn nhập vào so bat pho'
    number = gets.chomp.to_i
    if number > 2
      total_price = number * self.price - 10_000
      puts "#{self.name} #{total_price}vnd"
    else
      total_price = number * self.price
      puts "#{self.name} #{total_price}vnd"
    end
  end
end
# インスタンスメソッドの呼び出し
menu1 = Menu.new
menu1.name = 'Phở'
menu1.price = 30_000
menu1.get_total_price
