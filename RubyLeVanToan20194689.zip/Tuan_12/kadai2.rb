class Menu
  attr_accessor :name
  attr_accessor :price
  def show
    puts "#{self.name} #{self.price}vnd"
  end
end
menu1 = Menu.new
menu1.name = 'Phở'
menu1.price = 30000

menu2 = Menu.new
menu2.name = 'Bún chả'
menu2.price = 20000

menu3 = Menu.new
menu3.name = 'Bánh mì'
menu3.price = 15000

puts '-------------------'
puts menu1.show
puts menu2.show
puts menu3.show
puts '-------------------'
