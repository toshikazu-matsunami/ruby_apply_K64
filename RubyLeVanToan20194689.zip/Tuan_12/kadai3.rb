class Menu
  attr_accessor :name
  attr_accessor :price
  def show
    puts "#{self.name} #{self.price}vnd"
  end
end

class Drink < Menu 
    attr_accessor :super
  def show
    puts "#{self.name} #{self.price}vnd #{self.super}"
  end
end
menu1 = Menu.new
menu1.name = 'Phở'
menu1.price = 30000

menu2 = Menu.new
menu2.name = 'Bún chả'
menu2.price = 20000

menu3 = Menu.new
menu3.name = 'Bánh mì'
menu3.price = 15000

drink1 = Drink.new 
drink1.name = 'Trà'
drink1.price = 50000
drink1.super = 'Mサイズ'

drink2 = Drink.new
drink2.name = 'Trà'
drink2.price = 10000
drink2.super = 'Sサイズ'

puts '-------------------'
puts menu1.show
puts menu2.show
puts menu3.show
puts drink1.show
puts drink2.show
puts '-------------------'